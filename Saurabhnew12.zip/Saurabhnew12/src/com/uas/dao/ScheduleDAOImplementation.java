package com.uas.dao;

import java.util.ArrayList;

import javax.jms.Session;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ProgramBean;
import com.uas.bean.ScheduleBean;

@Repository
@Transactional
public class ScheduleDAOImplementation implements IScheduleDAO {
	static int count=0;
	

	@PersistenceContext 
	private EntityManager entitymanager;
	
	@Override
	public ArrayList<ProgramBean> viewAllProName() {
		Query proNameQuery= entitymanager.createQuery("select p.programName from ProgramBean p ");
		return  (ArrayList<ProgramBean>) proNameQuery.getResultList();		
	}

	
	@Override
	public int addScheduleDetails(ScheduleBean sb) {
		System.out.println("Inside dao layer");
		entitymanager.persist(sb);
		System.out.println("outside Dao layer");
		return sb.getScheduleProgramId();
	}
	
	@Override
	public ArrayList<ScheduleBean> viewAllScheduleDetails() {
		Query viewQuery=entitymanager.createNamedQuery("getAllSchedule");	
		
		return (ArrayList<ScheduleBean>) viewQuery.getResultList();
	}

	
	@Override
	public int deleteScheduleDetails(int deleteScheduleId) {
		
		

		Query deleteQuery=entitymanager.createQuery("delete ScheduleBean where scheduleProgramId =:delscheid");
		deleteQuery.setParameter("delscheid",deleteScheduleId);
		int result = deleteQuery.executeUpdate();
		return result;
	}
	


	@Override
	public ScheduleBean updateScheduleDetails(int scheId) {
		System.out.println("update 6");
		Query updateQuery=entitymanager.createQuery("select sb from ScheduleBean sb where scheduleProgramId =:upscheid");
		updateQuery.setParameter("upscheid", scheId);
		System.out.println("update 7");
		ScheduleBean ubs = (ScheduleBean) updateQuery.getSingleResult();
		System.out.println("update 8");
		return ubs;
	}
	@Override
	public int updateNewScheduleDetails(ScheduleBean usbo) {
		entitymanager.merge(usbo);
		return usbo.getScheduleProgramId();
	}



}

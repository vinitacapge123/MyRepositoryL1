package com.uas.service;

import org.springframework.stereotype.Service;



@Service
public class LoginServiceImpl implements ILoginService
{

	@Override
	public boolean validateLoginDetails(String usr, String pass) 
	{
		
		if(usr.equals("admin") && pass.equals("admin"))
		{
			return true;
		}
		
		

		return false;
			
		
	}

	@Override
	public boolean validateLoginDetails2(String usr, String pass) {
		
		if(usr.equals("mac") && pass.equals("mac"))
		{
			return true;
		}
		else
		{
			if(usr.equals("admin") && pass.equals("admin"))
			 return false;
		}
		
		 return false;
	

}
}

	



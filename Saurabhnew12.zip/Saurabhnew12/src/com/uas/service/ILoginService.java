package com.uas.service;


public interface ILoginService {


	boolean validateLoginDetails2(String usr, String pass);

	boolean validateLoginDetails(String usr, String pass);

	
	
}

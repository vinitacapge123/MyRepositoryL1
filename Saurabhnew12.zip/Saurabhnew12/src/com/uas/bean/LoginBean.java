package com.uas.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name="LoginBean")
@NamedQuery(name="loginquery",query="select u from LoginBean u where u.userName=:user and u.password=:pass ")
public class LoginBean 
{
	@Id
	private String userName;
	private String password;
	private String role;
	
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	
	
	public LoginBean(String userName, String password, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.role = role;
	}
	@Override
	public String toString() {
		return "    " + userName + ", password=" + password
				+ ", role=" + role + ", getRole()=" + getRole()
				+ ", getUserName()=" + getUserName() + ", getPassword()="
				+ getPassword() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	public LoginBean() {
		super();
	}
	
	

}
